package com.example.demo;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello from Java CI/CD Pipeline!");
    }
}