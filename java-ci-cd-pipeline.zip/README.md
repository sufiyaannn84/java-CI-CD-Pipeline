# Java CI/CD Pipeline Practice
This is a sample Java project with a Jenkins pipeline and Docker integration.